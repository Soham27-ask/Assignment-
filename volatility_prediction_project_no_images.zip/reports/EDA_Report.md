# EDA Report

Summary statistics and insights on volatility trends.