# Pipeline Architecture

Description of data flow and ML pipeline.