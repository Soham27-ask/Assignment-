# High Level Design (HLD)

Overview of the system architecture and components.