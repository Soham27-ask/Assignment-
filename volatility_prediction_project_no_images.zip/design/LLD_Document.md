# Low Level Design (LLD)

Detailed logic of preprocessing, model, and deployment pipeline.